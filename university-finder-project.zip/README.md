# University Finder

This is a simple web-based project to help students select their profession, scholarship options, and universities.  
Fully built using HTML, CSS, and JavaScript.

## How to Run
1. Open `index.html` directly in any browser.
2. Select your profession and scholarship option.
3. Browse universities and check their admission requirements.

## Technologies Used
- HTML5
- CSS3
- Vanilla JavaScript

## Future Improvements
- Backend API integration using Node.js and MongoDB.
- Responsive mobile-friendly UI.
- Real data fetching from a live database.
